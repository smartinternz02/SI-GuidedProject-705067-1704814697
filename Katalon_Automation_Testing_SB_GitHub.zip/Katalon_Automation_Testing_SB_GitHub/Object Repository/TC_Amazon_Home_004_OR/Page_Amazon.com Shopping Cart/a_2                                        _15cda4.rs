<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_2                                        _15cda4</name>
   <tag></tag>
   <elementGuidId>dd8ea413-42b8-4542-b6d6-1c9b02797454</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#nav-cart</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='nav-cart']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6ee0047d-b8a9-47ed-a1c4-648f5326c0c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/gp/cart/view.html?ref_=nav_cart</value>
      <webElementGuid>82ffdb3a-7d98-4c10-9cd0-3203466d3bce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>2 items in cart</value>
      <webElementGuid>57ec5000-3c05-4423-980e-177e553cc724</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-a nav-a-2 nav-progressive-attribute</value>
      <webElementGuid>1cb93539-3ec7-4eae-a519-7f8769c6945a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-cart</value>
      <webElementGuid>323b999d-2443-43d0-8d5f-b9d7f4f78985</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      2
      
    
    
      
        
      
      
        Cart
        
      
    
  </value>
      <webElementGuid>44d29511-1132-41a1-9547-9a552e7125ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-cart&quot;)</value>
      <webElementGuid>d2146944-d4b6-4267-9086-f1f024bc7d38</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='nav-cart']</value>
      <webElementGuid>211ec3c0-db4f-4657-b464-b7c150a0d9d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-tools']/a[5]</value>
      <webElementGuid>c082ebab-3dee-4e1c-bde9-4931d23719fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/gp/cart/view.html?ref_=nav_cart')]</value>
      <webElementGuid>a32f796d-7358-42cf-a2dd-d4218a086401</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[5]</value>
      <webElementGuid>a6e000b5-c66f-49d0-9b86-4a1597441f41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/gp/cart/view.html?ref_=nav_cart' and @id = 'nav-cart' and (text() = '
    
      2
      
    
    
      
        
      
      
        Cart
        
      
    
  ' or . = '
    
      2
      
    
    
      
        
      
      
        Cart
        
      
    
  ')]</value>
      <webElementGuid>62119ff1-b555-461b-aea4-cbf033a7217f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
