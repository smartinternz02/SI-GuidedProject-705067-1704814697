<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_ASELFAD Preserved Real Red Rose with I_147d3e</name>
   <tag></tag>
   <elementGuidId>43e254a3-e2f2-41b8-934d-a1438d1f274d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.a-size-mini.a-spacing-none.a-color-base.s-line-clamp-4 > a.a-link-normal.s-underline-text.s-underline-link-text.s-link-style.a-text-normal > span.a-size-base-plus.a-color-base.a-text-normal</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='search']/div/div/div/span/div/div[4]/div/div/div/div/span/div/div/div[2]/div/h2/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>3612a320-1471-4499-aa09-30611548ca71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-base-plus a-color-base a-text-normal</value>
      <webElementGuid>084f3c29-ee9a-4f8a-b438-74e84b47fd47</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ASELFAD Preserved Real Red Rose with I Love You Necklace -Eternal Flowers Rose Gifts for Mom Wife Girlfriend, Valentines Day Gifts for Her, Mothers Day Christmas Anniversary Birthday Gifts for Women</value>
      <webElementGuid>96f09d3d-e39c-4601-9d26-bb3811adb346</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;search&quot;)/div[@class=&quot;s-desktop-width-max s-desktop-content s-opposite-dir s-wide-grid-style sg-row&quot;]/div[@class=&quot;sg-col-20-of-24 s-matching-dir sg-col-16-of-20 sg-col sg-col-8-of-12 sg-col-12-of-16&quot;]/div[@class=&quot;sg-col-inner&quot;]/span[@class=&quot;rush-component s-latency-cf-section&quot;]/div[@class=&quot;s-main-slot s-result-list s-search-results sg-row&quot;]/div[@class=&quot;sg-col-4-of-24 sg-col-4-of-12 s-result-item s-asin sg-col-4-of-16 AdHolder sg-col s-widget-spacing-small sg-col-4-of-20&quot;]/div[@class=&quot;sg-col-inner&quot;]/div[@class=&quot;s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_2&quot;]/div[@class=&quot;rush-component s-expand-height&quot;]/div[@class=&quot;rush-component s-featured-result-item s-expand-height&quot;]/span[@class=&quot;a-declarative&quot;]/div[@class=&quot;puis-card-container s-card-container s-overflow-hidden aok-relative puis-expand-height puis-include-content-margin puis puis-v2rh3j15wdcp4q29xeaptoa72x6 s-latency-cf-section puis-card-border&quot;]/div[@class=&quot;a-section a-spacing-base&quot;]/div[@class=&quot;a-section a-spacing-small puis-padding-left-small puis-padding-right-small&quot;]/div[@class=&quot;a-section a-spacing-none a-spacing-top-small s-title-instructions-style&quot;]/h2[@class=&quot;a-size-mini a-spacing-none a-color-base s-line-clamp-4&quot;]/a[@class=&quot;a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal&quot;]/span[@class=&quot;a-size-base-plus a-color-base a-text-normal&quot;]</value>
      <webElementGuid>82cf8073-5532-4d92-99a6-016e9d36baa8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='search']/div/div/div/span/div/div[4]/div/div/div/div/span/div/div/div[2]/div/h2/a/span</value>
      <webElementGuid>db050ed2-268c-4830-8709-1308b9d601e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div/div/span/div/div/div[2]/div/h2/a/span</value>
      <webElementGuid>6100816d-09ca-45ca-babc-d1d12df2fd2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'ASELFAD Preserved Real Red Rose with I Love You Necklace -Eternal Flowers Rose Gifts for Mom Wife Girlfriend, Valentines Day Gifts for Her, Mothers Day Christmas Anniversary Birthday Gifts for Women' or . = 'ASELFAD Preserved Real Red Rose with I Love You Necklace -Eternal Flowers Rose Gifts for Mom Wife Girlfriend, Valentines Day Gifts for Her, Mothers Day Christmas Anniversary Birthday Gifts for Women')]</value>
      <webElementGuid>2c642dc6-e891-4acb-9cde-49208f2ceaea</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
