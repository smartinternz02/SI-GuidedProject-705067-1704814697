<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Top reviews from the United States</name>
   <tag></tag>
   <elementGuidId>bd2c2188-f6ac-4ade-8c74-1d42b5cac0ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3.a-spacing-medium.a-spacing-top-large</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='cm-cr-local-reviews-title']/h3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>2072b39e-d474-46fb-8532-1a3d9ea3f2da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-hook</name>
      <type>Main</type>
      <value>dp-local-reviews-header</value>
      <webElementGuid>c97f1586-525d-4d4c-a876-9a5920807274</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-medium a-spacing-top-large</value>
      <webElementGuid>a446c836-21e4-412d-9b81-ef122069d470</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>










  Top reviews from the United States
</value>
      <webElementGuid>3386fe7f-ae86-4c51-b996-11a403c81b79</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;cm-cr-local-reviews-title&quot;)/h3[@class=&quot;a-spacing-medium a-spacing-top-large&quot;]</value>
      <webElementGuid>9eb8e7de-a117-4e81-9e2b-581c924cdc16</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='cm-cr-local-reviews-title']/h3</value>
      <webElementGuid>6a81c446-1f80-4cdf-b759-bef50db70881</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/div/div/div/h3</value>
      <webElementGuid>104aac2a-34d7-4ece-b185-0422b6fe4ab4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '










  Top reviews from the United States
' or . = '










  Top reviews from the United States
')]</value>
      <webElementGuid>7645cc90-ee93-4fc1-a17a-dad8d9526261</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
